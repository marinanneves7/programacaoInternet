let valores = document.querySelector("#valores");

let valorprod = document.querySelector("#valorprod");

let valorpago = document.querySelector("#valorpago");

let btTroco = document.querySelector("#btTroco");


function troco(){

    let valor1 = Number(valorpago.value);

    //Convertendo o valor retornado no input em numero
    let valor2 = Number(valorprod.value);

    valores.textContent = valor1 - valor2;
}

btTroco.onclick = function(){
    troco(); 
}