let valor = document.querySelector("#valor");

let saldo = document.querySelector("#saldo");

let btSaldo = document.querySelector("#btSaldo");


function resultadoSaldo(){

    //Convertendo o valor retornado no input em numero
    let valorsaldo = Number(saldo.value);

    valor.textContent = valorsaldo * 1.1;
}

btSaldo.onclick = function(){
    resultadoSaldo(); 
}