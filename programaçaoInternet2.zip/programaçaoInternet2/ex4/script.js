let media1 = document.querySelector("#media1");

let media2 = document.querySelector("#media2");

let media3 = document.querySelector("#media3");

let btcalc = document.querySelector("#btcalc");

let h3medias = document.querySelector("#h3medias");                                           

function calculomedias (){

    //Convertendo em número

    let num1 = Number(media1.value);
    
    let num2 = Number(media2.value);

    let num3 = Number(media3.value);

    let mediaAritmetica = (num1 + num2 + num3)/3;

    //calcurar média ponderada
    //pesos 3,2 e 5
    // (num1 x p1) + (num2 x p2) + (num3 x p3) /(p1 + p2 + p3)

    let mediaPonderada = ((num1 * 3) + (num2 * 2) + (num3 * 5)) /(3 + 2 + 5);

    //soma das médias 
     
    let somaMedia = mediaAritmetica + mediaPonderada;

    //média das médias

    let mediaMedias = somaMedia / 2;

    h3medias.innerHTML = "Média Aritmética: " +mediaAritmetica+ "<br>"+
                        "Média Ponderada: " +mediaPonderada+ "<br>"+
                        "Soma das médias: " +somaMedia+ "<br>"+
                        "Media das Medias: " +mediaMedias;

}

btcalc.onclick = function(){
    calculomedias();
}
