let media1 = document.querySelector("#media1");

let media2 = document.querySelector("#media2");

let media3 = document.querySelector("#media3");

let btcalc = document.querySelector("#btcalc");

let h3medias = document.querySelector("#h3medias");                                           

function calculomedias (){
    
    let num1 = Number(media1.value);
    
    let num2 = Number(media2.value);

    let num3 = Number(media3.value);

    let media = (num1 + num2 + num3)/3;

    h3medias.textContent = media;

    console.log(media);
}

btcalc.onclick = function(){
    calculomedias();
}
