let valor1 = document.querySelector("#valor1");

let valor2 = document.querySelector("#valor2");

let btValor = document.querySelector("#btValor");

let h3Resultado = document.querySelector("#h3Resultado");


function retornaValor(){

    //Convertendo o valor retornado no input em numero
    let valores = Number(valor1.value);

    let valores2 = Number(valor2.value);

    if(valor1){
        h3Resultado.textContent = "Esse valor 1 é o maior";
    } else{
        h3Resultado.textContent = "Esse valor 2 é o menor";
    }

}

btValor.onclick = function(){
    retornaValor(); 
}