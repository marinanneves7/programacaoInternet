let valor1 = document.querySelector("#valor1");

let valor2 = document.querySelector("#valor2");

let valor3 = document.querySelector("#valor3");

let valor4 = document.querySelector("#valor4");

let btValor = document.querySelector("#btValor");

let h3Resultado = document.querySelector("#h3Resultado");


function retornaValor(){

    //Convertendo o valor retornado no input em numero
    let valores = Number(valor1.value);

    let valores2 = Number(valor2.value);

    let valores3 = Number(valor3.value);

    let valores4 = Number(valor4.value);

    let menor; 

    // Verifica o menor valor entre os 4 números usando if/else

    if(valores<=valores2 & valores<=valores3 & valores<=valores3){
        menor = valores;

    } else if(valores2<=valores & valores2<=valores3 & valores2<=valores4) {
        menor = valores2;
    }
    else if(valores3<=valores & valores3<=valores2 & valores3<=valores4) {
        menor = valores3
    }
    else{
        menor = valores4
    }
    h3Resultado.textContent = "O valor menor é: "+menor;
}


btValor.onclick = function(){
    retornaValor(); 
}