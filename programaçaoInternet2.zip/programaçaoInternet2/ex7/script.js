let valor1 = document.querySelector ("#valor1");

let btValor = document.querySelector ("#btValor"); 

let h3Valores = document.querySelector ("#h3Valores"); 

function retornandoValor() {

    let valor = Number(valor1.value);

    let par = 

    if (){

    }

}

btValor.onclick = function(){
    retornandoValor();
}