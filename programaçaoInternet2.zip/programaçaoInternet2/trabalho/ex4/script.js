let cargofunc = document.querySelector("#cargofunc");

let salario = document.querySelector("#salario")

let h3result = document.querySelector("#h3result");

let btcalc = document.querySelector("#btcalc");

function calcSalario(){

    num1 = Number(salario.value);
    


}


btcalc.onclick = function(){
    calcSalario
}