let pesoInput = document.querySelector("#peso");
let alturaInput = document.querySelector("#altura");
let botaoCalcular = document.querySelector("#botaoCalcular");
let resultadoIMC = document.querySelector("#resultadoIMC");

function calcularIMC() {
    let peso = Number(pesoInput.value);
    let altura = Number(alturaInput.value);

    let imc = peso / (altura * altura);
    let classificacao = "";

    if (imc < 18.5) {
        classificacao = "Abaixo do peso";
    } else if (imc < 25) {
        classificacao = "Peso normal";
    } else if (imc < 30) {
        classificacao = "Sobrepeso";
    } else if (imc < 35) {
        classificacao = "Obesidade grau 1";
    } else if (imc < 40) {
        classificacao = "Obesidade grau 2";
    } else {
        classificacao = "Obesidade grau 3";
    }

    resultadoIMC.textContent = `IMC: ${imc.toFixed(2)} - ${classificacao}`;
}

botaoCalcular.onclick = function() {
    calcularIMC();
};